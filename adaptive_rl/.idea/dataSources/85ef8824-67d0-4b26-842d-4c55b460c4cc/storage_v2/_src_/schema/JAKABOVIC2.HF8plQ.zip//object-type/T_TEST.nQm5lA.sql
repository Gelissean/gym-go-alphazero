create type t_test as object(
    a varchar2(20),
    b integer,
    member function meno return varchar2
);
/

