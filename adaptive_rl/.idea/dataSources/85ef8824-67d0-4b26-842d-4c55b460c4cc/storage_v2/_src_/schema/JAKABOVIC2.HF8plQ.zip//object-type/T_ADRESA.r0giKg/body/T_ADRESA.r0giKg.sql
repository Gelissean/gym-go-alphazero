create type body t_adresa
    is
        member function vypis return varchar2
            is
                begin
                    return ulica || ', ' || psc || ', ' || mesto;
                end;
end;
/

