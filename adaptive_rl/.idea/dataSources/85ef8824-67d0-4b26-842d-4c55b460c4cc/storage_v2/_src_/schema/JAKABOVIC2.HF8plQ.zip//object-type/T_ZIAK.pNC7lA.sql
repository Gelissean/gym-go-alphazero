create type t_ziak is object
(
 meno varchar2(20),
 priezvisko varchar2(20)
)
 alter type t_ziak add member function vypis return varchar
/

