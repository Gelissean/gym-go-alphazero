create procedure vypis_studentov( rocnik IN student.rocnik%TYPE)
as
    cursor cur1 ( p_rocnik student.rocnik%TYPE) IS
        select st.os_cislo as oc, ou.meno as meno, ou.priezvisko as priezv, st.st_sk_new as skupina
        from priklad_db2.student st JOIN priklad_db2.os_udaje ou USING (rod_cislo)
            where st.rocnik = p_rocnik
            order by st.st_sk_new, ou.priezvisko, ou.meno;
    TYPE t_st_rec IS RECORD(
        oc number(38),
        meno varchar2(15),
        priezv varchar2(15),
        skupina char(6));
    st_rec cur1%ROWTYPE;
begin
    OPEN cur1(rocnik);
    LOOP
        FETCH cur1 INTO st_rec;
        IF cur1%NOTFOUND THEN
            EXIT;
        ELSE
            dbms_output.put(st_rec.oc||' ');
            dbms_output.put(st_rec.meno||' '||st_rec.priezv||' ');
            dbms_output.put_line(st_rec.skupina);
        END IF;
        END LOOP;
    CLOSE cur1;
end;
/

