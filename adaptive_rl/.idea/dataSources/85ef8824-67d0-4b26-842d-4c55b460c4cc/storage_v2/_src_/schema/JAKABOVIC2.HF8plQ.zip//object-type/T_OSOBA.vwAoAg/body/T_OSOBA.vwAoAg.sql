create type body t_osoba
    is
        member function vypis_adresu return varchar2
            is
                begin
                    return adresa.vypis();
                end;
end;
/

