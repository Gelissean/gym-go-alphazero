create type t_osoba as object(
        meno varchar2(15),
        priezvisko VARCHAR2(15),
        rod_cislo VARCHAR2(10),
        adresa t_adresa,
        member function vypis_adresu return varchar2
        )
 ALTER TYPE t_osoba add map member function mapuj return real cascade
/

