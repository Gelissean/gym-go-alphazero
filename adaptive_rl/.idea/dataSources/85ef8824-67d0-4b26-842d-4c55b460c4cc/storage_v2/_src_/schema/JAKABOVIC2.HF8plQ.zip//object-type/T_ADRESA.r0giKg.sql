create type t_adresa as object(
        ulica varchar2(20),
        psc varchar2(5),
        mesto varchar2(20),
        member function vypis return varchar2
        );
/

